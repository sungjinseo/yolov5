
dog eye - v1 2022-06-09 1:36am
==============================

This dataset was exported via roboflow.ai on June 8, 2022 at 5:36 PM GMT

It includes 200 images.
Eye are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


